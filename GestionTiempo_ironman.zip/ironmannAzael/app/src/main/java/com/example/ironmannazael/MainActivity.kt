package com.example.ironmannazael

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.reflect.KFunction1

class MainActivity : AppCompatActivity() {

    // Variables para los contadores de cada sección
    private var tiempoNatacion = 0
    private var tiempoCiclismo = 0
    private var tiempoRunning = 0
    private var tiempoTransicion1 = 0.00
    private var tiempoTransicion2 = 0.00


    private lateinit var tvTiempoNatacion: TextView
    private lateinit var tvTiempoCiclismo: TextView
    private lateinit var tvTiempoRunning: TextView
    private lateinit var tvTiempoTransicion1: TextView
    private lateinit var tvTiempoTransicion2: TextView
    private lateinit var tvTiempoTotal: TextView

    private lateinit var btnMasDiezNatacion: ImageButton
    private lateinit var btnMasCincoNatacion: ImageButton
    private lateinit var btnMasUnoNatacion: ImageButton
    private lateinit var btnMenosUnoNatacion: ImageButton
    private lateinit var btnMenosCincoNatacion: ImageButton
    private lateinit var btnMenosDiezNatacion: ImageButton
    private lateinit var btnMenosDiezCiclismo: ImageButton
    private lateinit var btnMenosCincoCiclismo: ImageButton
    private lateinit var btnMenosUnoCiclismo: ImageButton
    private lateinit var btnMasDiezCiclismo: ImageButton
    private lateinit var btnMasCincoCiclismo: ImageButton
    private lateinit var btnMasUnoCiclismo: ImageButton
    private lateinit var btnMenosDiezRunning: ImageButton
    private lateinit var btnMenosCincoRunning: ImageButton
    private lateinit var btnMenosUnoRunning: ImageButton
    private lateinit var btnMasDiezRunning: ImageButton
    private lateinit var btnMasCincoRunning: ImageButton
    private lateinit var btnMasUnoRunning: ImageButton
    private lateinit var btnMasceroocincot1: ImageButton
    private lateinit var btnMenosceroocincot1: ImageButton
    private lateinit var btnMasceroocincot2: ImageButton
    private lateinit var btnMenosceroocincot2: ImageButton


    private lateinit var imgReloj: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        inicializarComponentes() // Inicializa los componentes de la UI
        inicializarListeners() // Configura los listeners para los botones
        menu() // Establece valores iniciales para la vista
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Función para inicializar componentes de la UI
    private fun inicializarComponentes() {

        tvTiempoNatacion = findViewById(R.id.tvTiempoNatacion)
        tvTiempoCiclismo = findViewById(R.id.tvTiempoCiclismo)
        tvTiempoRunning = findViewById(R.id.tvTiempoRunning)
        tvTiempoTransicion1 = findViewById(R.id.tvTiempot1)
        tvTiempoTransicion2 = findViewById(R.id.tvTiempot2)
        tvTiempoTotal = findViewById(R.id.tvTiempoTotal)

        btnMasDiezNatacion = findViewById(R.id.btnMasDiezNatacion)
        btnMasCincoNatacion = findViewById(R.id.btnMasCincoNatacion)
        btnMasUnoNatacion = findViewById(R.id.btnMasUnoNatacion)
        btnMenosUnoNatacion = findViewById(R.id.btnMenosUnoNatacion)
        btnMenosCincoNatacion = findViewById(R.id.btnMenosCincoNatacion)
        btnMenosDiezNatacion = findViewById(R.id.btnMenosDiezNatacion)

        btnMasDiezCiclismo = findViewById(R.id.btnMasDiezCiclismo)
        btnMasCincoCiclismo = findViewById(R.id.btnMasCincoCiclismo)
        btnMasUnoCiclismo = findViewById(R.id.btnMasUnoCiclismo)
        btnMenosUnoCiclismo = findViewById(R.id.btnMenosUnoCiclismo)
        btnMenosCincoCiclismo = findViewById(R.id.btnMenosCincoCiclismo)
        btnMenosDiezCiclismo = findViewById(R.id.btnMenosDiezCiclismo)

        btnMasDiezRunning = findViewById(R.id.btnMasDiezRunning)
        btnMasCincoRunning = findViewById(R.id.btnMasCincoRunning)
        btnMasUnoRunning = findViewById(R.id.btnMasUnoRunning)
        btnMenosUnoRunning = findViewById(R.id.btnMenosUnoRunning)
        btnMenosCincoRunning = findViewById(R.id.btnMenosCincoRunning)
        btnMenosDiezRunning = findViewById(R.id.btnMenosDiezRunning)

        btnMasceroocincot1 = findViewById(R.id.btnMasceroocincot1)
        btnMenosceroocincot1 = findViewById(R.id.btnMenosceroocincot1)

        btnMasceroocincot2 = findViewById(R.id.btnMasceroocincot2)
        btnMenosceroocincot2 = findViewById(R.id.btnMenosceroocincot2)


        // Repite la inicialización para otros botones de las secciones

        imgReloj = findViewById(R.id.imgReloj)
    }

    // Función para inicializar listeners
    private fun inicializarListeners() {

        configurarBotonesSeccion(btnMasDiezNatacion, 10, ::agregarTiempoNatacion)
        configurarBotonesSeccion(btnMasCincoNatacion, 5, ::agregarTiempoNatacion)
        configurarBotonesSeccion(btnMasUnoNatacion, 1, ::agregarTiempoNatacion)
        configurarBotonesSeccion(btnMenosUnoNatacion, -1, ::agregarTiempoNatacion)
        configurarBotonesSeccion(btnMenosCincoNatacion, -5, ::agregarTiempoNatacion)
        configurarBotonesSeccion(btnMenosDiezNatacion, -10, ::agregarTiempoNatacion)

        configurarBotonesSeccion(btnMasDiezCiclismo, 10, ::agregarTiempoCiclismo)
        configurarBotonesSeccion(btnMasCincoCiclismo, 5, ::agregarTiempoCiclismo)
        configurarBotonesSeccion(btnMasUnoCiclismo, 1, ::agregarTiempoCiclismo)
        configurarBotonesSeccion(btnMenosUnoCiclismo, -1, ::agregarTiempoCiclismo)
        configurarBotonesSeccion(btnMenosCincoCiclismo, -5, ::agregarTiempoCiclismo)
        configurarBotonesSeccion(btnMenosDiezCiclismo, -10, ::agregarTiempoCiclismo)

        configurarBotonesSeccion(btnMasDiezRunning, 10, ::agregarTiempoRunning)
        configurarBotonesSeccion(btnMasCincoRunning, 5, ::agregarTiempoRunning)
        configurarBotonesSeccion(btnMasUnoRunning, 1, ::agregarTiempoRunning)
        configurarBotonesSeccion(btnMenosUnoRunning, -1, ::agregarTiempoRunning)
        configurarBotonesSeccion(btnMenosCincoRunning, -5, ::agregarTiempoRunning)
        configurarBotonesSeccion(btnMenosDiezRunning, -10, ::agregarTiempoRunning)

        configurarBotonesSeccionTransicciones(btnMasceroocincot1, +0.05, ::agregarTiempoTransicion1)
        configurarBotonesSeccionTransicciones(btnMenosceroocincot1, -0.05, :: agregarTiempoTransicion1)
        configurarBotonesSeccionTransicciones(btnMasceroocincot2, +0.05, ::agregarTiempoTransicion2)
        configurarBotonesSeccionTransicciones(btnMenosceroocincot2, -0.05, ::agregarTiempoTransicion2)

        imgReloj.setOnClickListener { resetearTiempos() }
    }

    // Función que establece los valores iniciales de la vista
    private fun menu() {
        // Asigna los valores iniciales de los TextViews de cada sección
        tvTiempoNatacion.text = formatearTiempo(tiempoNatacion)
        tvTiempoCiclismo.text = formatearTiempo(tiempoCiclismo)
        tvTiempoRunning.text = formatearTiempo(tiempoRunning)
        tvTiempoTransicion1.text = formatearTiempoDecimal(tiempoTransicion1)
        tvTiempoTransicion2.text = formatearTiempoDecimal(tiempoTransicion2)
        tvTiempoTotal.text = "TIEMPO TOTAL: 00:00"
    }

    // Configura un botón para agregar o restar tiempo en una sección específica
    private fun configurarBotonesSeccion(button: ImageButton, increment: Int, action: (Int) -> Unit) {
        button.setOnClickListener {
            action(increment)
            actualizarTiempoTotal()
        }
    }

    private fun configurarBotonesSeccionTransicciones(button: ImageButton, increment: Double, action: KFunction1<Double, Unit>) {
        button.setOnClickListener {
            action(increment)
            actualizarTiempoTotal()
        }
    }

    // Métodos para sumar o restar tiempo en cada sección y actualizar el TextView
    private fun agregarTiempoNatacion(tiempo: Int) {

        if (tiempoNatacion + tiempo >= 0) {

            tiempoNatacion += tiempo
            tvTiempoNatacion.text = formatearTiempo(tiempoNatacion)

        }

    }

    private fun agregarTiempoCiclismo(tiempo: Int) {

        if (tiempoCiclismo + tiempo >= 0) {

            tiempoCiclismo += tiempo
            tvTiempoCiclismo.text = formatearTiempo(tiempoCiclismo)

        }

    }

    private fun agregarTiempoRunning(tiempo: Int) {

        if (tiempoRunning + tiempo >= 0){

            tiempoRunning += tiempo
            tvTiempoRunning.text = formatearTiempo(tiempoRunning)

        }

    }

    private fun agregarTiempoTransicion1(tiempo: Double) {

        if (tiempoTransicion1 + tiempo >= 0){

            tiempoTransicion1 += tiempo
            tvTiempoTransicion1.text = formatearTiempoDecimal(tiempoTransicion1)

        }

    }

    private fun agregarTiempoTransicion2(tiempo: Double) {

        if (tiempoTransicion2 + tiempo >= 0){

            tiempoTransicion2 += tiempo
            tvTiempoTransicion2.text = formatearTiempoDecimal(tiempoTransicion2)

        }

    }

    // Método para actualizar el tiempo total
    private fun actualizarTiempoTotal() {

        val tiempoTotal = tiempoNatacion + tiempoCiclismo + tiempoRunning +
                tiempoTransicion1 + tiempoTransicion2
        // Formatea el tiempo total en minutos, segundos y décimas
        tvTiempoTotal.text = "TIEMPO TOTAL: ${formatearTiempoDecimal(tiempoTotal)}"
    }

    // Método para resetear todos los tiempos
    private fun resetearTiempos() {
        tiempoNatacion = 0
        tiempoCiclismo = 0
        tiempoRunning = 0
        tiempoTransicion1 = 0.00
        tiempoTransicion2 = 0.00
        tvTiempoNatacion.text = formatearTiempo(tiempoNatacion)
        tvTiempoCiclismo.text = formatearTiempo(tiempoCiclismo)
        tvTiempoRunning.text = formatearTiempo(tiempoRunning)
        tvTiempoTransicion1.text = formatearTiempoDecimal(tiempoTransicion1)
        tvTiempoTransicion2.text = formatearTiempoDecimal(tiempoTransicion2)
        tvTiempoTotal.text = "TIEMPO TOTAL: 00:00"
    }

    // Función para formatear el tiempo en minutos y segundos
    private fun formatearTiempo(segundos: Int): String {
        val minutos = segundos / 60
        val segundosRestantes = segundos % 60
        return String.format("%02d:%02d", minutos, segundosRestantes)
    }

    // Función para formatear el tiempo en minutos, segundos y decimales
    private fun formatearTiempoDecimal(tiempo: Double): String {
        val minutos = tiempo.toInt() / 60
        val segundos = tiempo.toInt() % 60
        val decimas = ((tiempo - tiempo.toInt()) * 100).toInt() // Convierte decimales a dos dígitos
        return String.format("%02d:%02d.%02d", minutos, segundos, decimas)
    }
}