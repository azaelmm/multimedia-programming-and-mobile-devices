package com.example.ejerbotones12azael

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

private lateinit var tvHello : TextView
private lateinit var tvJuego : TextView
private lateinit var tvBuenaSuerte : TextView
private lateinit var tvNorma1 : TextView
private lateinit var tvNorma2 : TextView
private lateinit var tvNorma3 : TextView
private lateinit var btnEmpezarJugar : Button
private lateinit var tvTiempo : TextView
private lateinit var tvJugadasTotales : TextView
private lateinit var btnPuls01 : Button
private lateinit var btnPuls02 : Button
private lateinit var btnPuls03 : Button
private lateinit var btnPuls04 : Button
private lateinit var btnPuls05 : Button
private lateinit var btnPuls06 : Button
private lateinit var btnPuls07 : Button
private lateinit var btnPuls08 : Button
private lateinit var btnPuls09 : Button
private lateinit var btnPuls10 : Button
private lateinit var btnPuls11 : Button
private lateinit var btnPuls12 : Button
private lateinit var btnReset : Button
private lateinit var etPlayerName : EditText
private lateinit var tvBestPlayer : TextView
private lateinit var tvLastPlays : TextView



private var tiempoRestante:Int = 0;
private var jugadas:Int = 0;
private var juegoEnCurso:Boolean = false;
private var playerName = "Desconocido"
private var bestPlayer = ""
private var bestScore = 0
private val lastFivePlays = mutableListOf<String>()

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        initComponents()
        initListeners()
        inicio()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    public fun inicio(){

        playerName = "Desconocido"
        juegoEnCurso = true;
        tiempoRestante = 10;
        tvTiempo.text = "Tiempo restante: " + tiempoRestante.toString() + " seg."
        btnReset.isEnabled = false
        btnEmpezarJugar.isEnabled = true
        jugadas = 0
        tvJugadasTotales.text = "jugadas totales: "+ jugadas.toString() + " botones."
        ocultarBotones()

    }



    public fun initComponents (){

        tvHello = findViewById(R.id.tvHello)
        tvJuego = findViewById(R.id.tvJuego)
        tvBuenaSuerte = findViewById(R.id.tvBuenaSuerte)
        tvNorma1 = findViewById(R.id.tvNorma1)
        tvNorma2 = findViewById(R.id.tvNorma2)
        tvNorma3 = findViewById(R.id.tvNorma3)
        btnEmpezarJugar = findViewById(R.id.btnEmpezarJugar)
        tvTiempo = findViewById(R.id.tvTiempo)
        tvJugadasTotales = findViewById(R.id.tvJugadasTotales)
        btnPuls01 = findViewById(R.id.btnPuls01)
        btnPuls02 = findViewById(R.id.btnPuls02)
        btnPuls03 = findViewById(R.id.btnPuls03)
        btnPuls04 = findViewById(R.id.btnPuls04)
        btnPuls05 = findViewById(R.id.btnPuls05)
        btnPuls06 = findViewById(R.id.btnPuls06)
        btnPuls07 = findViewById(R.id.btnPuls07)
        btnPuls08 = findViewById(R.id.btnPuls08)
        btnPuls09 = findViewById(R.id.btnPuls09)
        btnPuls10 = findViewById(R.id.btnPuls10)
        btnPuls11 = findViewById(R.id.btnPuls11)
        btnPuls12 = findViewById(R.id.btnPuls12)
        btnReset = findViewById(R.id.btnReset)
        etPlayerName = findViewById(R.id.etPlayerName)
        tvBestPlayer = findViewById(R.id.tvBestPlayer)
        tvLastPlays = findViewById(R.id.tvLastPlays)

        botonesPulsadosContador(btnPuls01)
        botonesPulsadosContador(btnPuls02)
        botonesPulsadosContador(btnPuls03)
        botonesPulsadosContador(btnPuls04)
        botonesPulsadosContador(btnPuls05)
        botonesPulsadosContador(btnPuls06)
        botonesPulsadosContador(btnPuls07)
        botonesPulsadosContador(btnPuls08)
        botonesPulsadosContador(btnPuls09)
        botonesPulsadosContador(btnPuls10)
        botonesPulsadosContador(btnPuls11)
        botonesPulsadosContador(btnPuls12)

    }

    public fun initListeners (){

        btnEmpezarJugar.setOnClickListener{
            jugar()
        }

        btnReset.setOnClickListener{
            reset()
        }
    }

    private fun reset() {

        btnEmpezarJugar.isEnabled = true
        btnReset.isEnabled = false
        val player = etPlayerName.text.toString()
        updateScore(player)
        inicio()

    }

    private fun jugar() {

        btnEmpezarJugar.isEnabled = false
        var postDelayed01 = android.os.Handler().postDelayed({
            cuentaAtrasTexto() }, 1000)
        var postDelayed02 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 2000)
        var postDelayed03 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 3000)
        var postDelayed04 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 4000)
        var postDelayed05 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 5000)
        var postDelayed06 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 6000)
        var postDelayed07 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 7000)
        var postDelayed08 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 8000)
        var postDelayed09 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()        }, 9000)
        var postDelayed10 = android.os.Handler().postDelayed({
            cuentaAtrasTexto()
            btnReset.isEnabled = true
            juegoEnCurso = false; }, 10000)

        mostrarBotonesRandom()


    }

    private fun mostrarBotonesRandom() {

        val numRandom = Random.nextInt(1, 12)
        when (numRandom) {

            1->btnPuls01.isEnabled = true
            2->btnPuls02.isEnabled = true
            3->btnPuls03.isEnabled = true
            4->btnPuls04.isEnabled = true
            5->btnPuls05.isEnabled = true
            6->btnPuls06.isEnabled = true
            7->btnPuls07.isEnabled = true
            8->btnPuls08.isEnabled = true
            9->btnPuls09.isEnabled = true
            10->btnPuls10.isEnabled = true
            11->btnPuls11.isEnabled = true
            12->btnPuls12.isEnabled = true
        }

    }

    private fun ocultarBotones() {
        btnPuls01.isEnabled = false
        btnPuls02.isEnabled = false
        btnPuls03.isEnabled = false
        btnPuls04.isEnabled = false
        btnPuls05.isEnabled = false
        btnPuls06.isEnabled = false
        btnPuls07.isEnabled = false
        btnPuls08.isEnabled = false
        btnPuls09.isEnabled = false
        btnPuls10.isEnabled = false
        btnPuls11.isEnabled = false
        btnPuls12.isEnabled = false

    }

    private fun cuentaAtrasTexto() {

        tiempoRestante -= 1
        tvTiempo.text = "Tiempo restante: " + tiempoRestante.toString() + " seg."

    }

    private fun botonesPulsadosContador(Button: Button) {

        Button.setOnClickListener() {
            if (juegoEnCurso) {
                jugadas += 1
                tvJugadasTotales.text = "jugadas totales: "+ jugadas.toString() + " botones."
                Button.isEnabled = false
                mostrarBotonesRandom()
            }
        }

    }

    private fun updateUI(tvBestPlayer: TextView, tvLastPlays: TextView) {

        tvBestPlayer.text = "Record de puntos: \n Best: $bestPlayer $bestScore"
        tvLastPlays.text = "Últimas jugadas:\n" + lastFivePlays.joinToString("\n")
    }

    private fun updateScore(player: String) {
        if (player.isNotEmpty()) {
            playerName = player
        }

        if (lastFivePlays.size == 5) {
            lastFivePlays.removeAt(0)  // Elimina el más antiguo
        }
        lastFivePlays.add(0, "$playerName: $jugadas")  // Añade la nueva jugada al principio

        if (jugadas > bestScore) {
            bestPlayer = playerName
            bestScore = jugadas
        }

        updateUI(tvBestPlayer, tvLastPlays)
    }
}